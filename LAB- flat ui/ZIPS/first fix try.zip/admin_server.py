import os
import json
from datetime import datetime, date
from flask import Flask, jsonify, request, send_from_directory

# ==========================================================
# APP
# ==========================================================

app = Flask(__name__)

BASE_DIR = r"C:\Users\Admin\Desktop\QC Dashboard"

# ==========================================================
# DEPARTMENT JSON LOCATIONS
# ==========================================================

CHART_LOG_PATH = r"C:\Users\Admin\Desktop\QC Dashboard\chart_log.json"
AUDIT_LOG_PATH = r"C:\Users\Admin\Desktop\QC Dashboard\audit_log.json"
AUDIT_LOG_MAX  = 1000

DEPARTMENTS = {
    "CUTTING": r"C:\Users\Admin\Desktop\QC Dashboard\CUTTING\data.json",
    "EMBRO":   r"C:\Users\Admin\Desktop\QC Dashboard\EMBRO\data.json",
}

DEFAULT_DEFECTS_CUTTING = {
    "WRONG_COLOR":    0,
    "WRONG_SIZE":     0,
    "WRONG_CUT":      0,
    "OFF_SHADE":      0,
    "LOW_QUALITY":    0,
    "WRONG_MATERIAL": 0,
    "OTHERS":         0,
}

DEFAULT_DEFECTS_EMBRO = {
    "LOW_QUALITY":        0,
    "WRONG_COLOR_THREAD": 0,
    "WRONG_PLACEMENT":    0,
    "WRONG_TEXT_FONT":    0,
    "UNBALANCED":         0,
    "WRONG_SPELLING":     0,
    "OTHERS":             0,
}

DEFAULT_DATA_CUTTING = {
    "employees": [
        {"name": "Employee 1", "defects": dict(DEFAULT_DEFECTS_CUTTING)},
        {"name": "Employee 2", "defects": dict(DEFAULT_DEFECTS_CUTTING)},
        {"name": "Employee 3", "defects": dict(DEFAULT_DEFECTS_CUTTING)},
    ]
}

DEFAULT_DATA_EMBRO = {
    "employees": [
        {"name": "Employee 1", "defects": dict(DEFAULT_DEFECTS_EMBRO)},
        {"name": "Employee 2", "defects": dict(DEFAULT_DEFECTS_EMBRO)},
        {"name": "Employee 3", "defects": dict(DEFAULT_DEFECTS_EMBRO)},
    ]
}

DEPT_DEFAULT_DATA = {
    "CUTTING": DEFAULT_DATA_CUTTING,
    "EMBRO":   DEFAULT_DATA_EMBRO,
}

# ==========================================================
# BOOTSTRAP — create data.json inside each dept folder
# ==========================================================

def bootstrap():
    for dept, path in DEPARTMENTS.items():
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        if not os.path.exists(path):
            default_data = DEPT_DEFAULT_DATA.get(dept, DEFAULT_DATA_EMBRO)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(default_data, f, indent=2)
            print(f"[BOOTSTRAP] Created {path}")
        else:
            print(f"[OK] {dept} -> {path}")

# ==========================================================
# HELPERS
# ==========================================================

def load_chart_log():
    """Load chart log, auto-reset if last_reset date < today (past 6 AM)."""
    try:
        if os.path.exists(CHART_LOG_PATH):
            with open(CHART_LOG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = {}
    except Exception:
        data = {}

    now = datetime.now()
    # 6 AM reset boundary: today at 06:00
    reset_boundary = datetime(now.year, now.month, now.day, 6, 0, 0)
    if now.hour < 6:
        # Before 6am — yesterday's 6am was the boundary
        from datetime import timedelta
        reset_boundary = reset_boundary - timedelta(days=1)

    last_reset_str = data.get("last_reset", "")
    needs_reset = True
    if last_reset_str:
        try:
            last_reset_dt = datetime.fromisoformat(last_reset_str)
            if last_reset_dt >= reset_boundary:
                needs_reset = False
        except Exception:
            pass

    if needs_reset:
        data = {
            "last_reset": reset_boundary.isoformat(),
            "entries": []
        }
        save_chart_log(data)
        print(f"[CHART LOG] Reset at 6AM boundary ({reset_boundary})")

    return data


def save_chart_log(data):
    try:
        os.makedirs(os.path.dirname(CHART_LOG_PATH), exist_ok=True)
        with open(CHART_LOG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print("Chart Log Save Error:", e)
        return False


def append_chart_entry(department, total_defects):
    data = load_chart_log()
    now = datetime.now()
    entry = {
        "timestamp": now.isoformat(),
        "hour_fraction": round(now.hour + now.minute / 60 + now.second / 3600, 4),
        "department": department,
        "total": total_defects
    }
    data.setdefault("entries", []).append(entry)
    save_chart_log(data)


def _normalize_employees(employees):
    """Ensure every defect key is stored in UPPER_CASE so the tray app and
    the admin dashboard always agree on the key format regardless of which
    client wrote the file last."""
    if not isinstance(employees, list):
        return employees
    normalized = []
    for emp in employees:
        if not isinstance(emp, dict):
            normalized.append(emp)
            continue
        defects = emp.get("defects", {})
        if isinstance(defects, dict):
            emp = dict(emp)
            emp["defects"] = {k.upper(): max(0, int(v or 0)) for k, v in defects.items()}
        normalized.append(emp)
    return normalized


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Always normalize employee defect keys to UPPER_CASE so both the
        # tray app (which may write lowercase keys) and the admin dashboard
        # (which expects uppercase keys) stay in sync.
        if isinstance(data, dict) and "employees" in data:
            data["employees"] = _normalize_employees(data["employees"])
        return data
    except Exception as e:
        print("Load Error:", e)
        return {"employees": []}


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print("Save Error:", e)
        return False


def load_audit_log():
    try:
        if os.path.exists(AUDIT_LOG_PATH):
            with open(AUDIT_LOG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and isinstance(data.get("entries"), list):
                    return data
    except Exception:
        pass
    return {"entries": []}


def save_audit_log(data):
    try:
        entries = data.get("entries", [])
        if len(entries) > AUDIT_LOG_MAX:
            data["entries"] = entries[-AUDIT_LOG_MAX:]
        with open(AUDIT_LOG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print("Audit Log Save Error:", e)
        return False


def _normalize_defects(defects):
    if not isinstance(defects, dict):
        return {}
    out = {}
    for k, v in defects.items():
        try:
            out[str(k).upper()] = max(0, int(v or 0))
        except (TypeError, ValueError):
            out[str(k).upper()] = 0
    return out


def compute_employee_changes(before_emps, after_emps):
    before_emps = before_emps if isinstance(before_emps, list) else []
    after_emps  = after_emps  if isinstance(after_emps, list)  else []
    changes = []

    if len(after_emps) < len(before_emps):
        for i in range(len(after_emps), len(before_emps)):
            changes.append({
                "type": "employee_removed",
                "employee": before_emps[i].get("name", "Unknown"),
            })

    if len(after_emps) > len(before_emps):
        for i in range(len(before_emps), len(after_emps)):
            changes.append({
                "type": "employee_added",
                "employee": after_emps[i].get("name", "Unknown"),
            })

    for i in range(min(len(before_emps), len(after_emps))):
        before = before_emps[i]
        after  = after_emps[i]
        before_name = str(before.get("name") or "").strip() or "Unknown"
        after_name  = str(after.get("name") or "").strip() or "Unknown"

        if before_name != after_name:
            changes.append({
                "type": "employee_renamed",
                "from": before_name,
                "to": after_name,
            })

        b_def = _normalize_defects(before.get("defects"))
        a_def = _normalize_defects(after.get("defects"))
        defect_changes = {}
        for key in set(b_def) | set(a_def):
            old_val = b_def.get(key, 0)
            new_val = a_def.get(key, 0)
            if old_val != new_val:
                defect_changes[key] = {"from": old_val, "to": new_val}

        if defect_changes:
            changes.append({
                "type": "defects_updated",
                "employee": after_name,
                "changes": defect_changes,
            })

    return changes


def summarize_changes(action, changes):
    if action == "reset":
        return "All defect counters reset to 0"
    if not changes:
        return "Saved with no detected changes"

    parts = []
    for item in changes:
        kind = item.get("type")
        if kind == "employee_added":
            parts.append("added " + item.get("employee", "?"))
        elif kind == "employee_removed":
            parts.append("removed " + item.get("employee", "?"))
        elif kind == "employee_renamed":
            parts.append(item.get("from", "?") + " renamed to " + item.get("to", "?"))
        elif kind == "defects_updated":
            count = len(item.get("changes") or {})
            parts.append(item.get("employee", "?") + ": " + str(count) + " field(s)")

    return "; ".join(parts) if parts else "Changes saved"


def append_audit_entry(department, action, user, changes):
    data = load_audit_log()
    now  = datetime.now()
    entry = {
        "timestamp":  now.isoformat(),
        "user":        str(user or "unknown").strip() or "unknown",
        "department":  department,
        "action":      action,
        "changes":     changes,
        "summary":     summarize_changes(action, changes),
    }
    data.setdefault("entries", []).append(entry)
    save_audit_log(data)
    return entry

# ==========================================================
# ROUTES
# ==========================================================

@app.route("/")
def index():
    resp = send_from_directory(BASE_DIR, "admin_dashboard.html")
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp

@app.route("/logo.png")
def logo():
    resp = send_from_directory(BASE_DIR, "logo.png")
    resp.headers["Cache-Control"] = "public, max-age=86400"
    return resp

@app.route("/favicon.ico")
def favicon():
    # suppress 404 noise
    return "", 204

@app.route("/users.json")
def users():
    """Serve the credentials file so the login overlay can authenticate."""
    return send_from_directory(BASE_DIR, "users.json")


@app.route("/api/departments")
def departments():
    result = {}
    for dept, path in DEPARTMENTS.items():
        result[dept] = load_json(path)
    return jsonify(result)


@app.route("/api/chart-log")
def get_chart_log():
    data = load_chart_log()
    return jsonify(data)


@app.route("/api/audit-log")
def get_audit_log():
    data = load_audit_log()
    entries = list(reversed(data.get("entries", [])))
    return jsonify({"entries": entries})


@app.route("/api/update", methods=["POST"])
def update_department():
    try:
        body       = request.get_json(force=True)
        department = body.get("department")
        employees  = body.get("employees")
        updated_by = body.get("updated_by") or body.get("username") or "unknown"

        print(f"\n========== SAVE: {department} by {updated_by} ==========")

        if department not in DEPARTMENTS:
            return jsonify({"ok": False, "error": "Department not found"}), 404

        path          = DEPARTMENTS[department]
        existing_data = load_json(path)
        before_emps   = existing_data.get("employees", [])

        # Normalize incoming employee defect keys to UPPER_CASE so that
        # saves from the tray app (lowercase) and the admin dashboard
        # (uppercase) are stored identically and stay in sync.
        employees = _normalize_employees(employees)

        changes       = compute_employee_changes(before_emps, employees)
        now           = datetime.now()

        existing_data["employees"]       = employees
        existing_data["last_updated"]    = now.isoformat()
        existing_data["last_updated_by"] = str(updated_by).strip() or "unknown"

        if not save_json(path, existing_data):
            return jsonify({"ok": False, "error": "Save failed"}), 500

        total_defects = sum(
            v for emp in employees for v in emp.get("defects", {}).values()
        )
        append_chart_entry(department, total_defects)
        append_audit_entry(department, "update", updated_by, changes)

        print(f"Saved -> {path}")
        return jsonify({"ok": True})

    except Exception as e:
        print("Update Error:", e)
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/api/export", methods=["POST"])
def export_department():
    try:
        body       = request.get_json(force=True)
        department = body.get("department")
        if department not in DEPARTMENTS:
            return jsonify({"ok": False, "error": "Department not found"}), 404

        from io import BytesIO
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill
        except ImportError:
            return jsonify({"ok": False, "error": "openpyxl not installed. Run: pip install openpyxl"}), 500

        data      = load_json(DEPARTMENTS[department])
        employees = data.get("employees", [])
        if not employees:
            return jsonify({"ok": False, "error": "No data to export"}), 400

        categories = list(employees[0].get("defects", {}).keys())

        wb = Workbook()
        ws = wb.active
        ws.title = department

        header      = ["Employee"] + categories + ["Total"]
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="1e40af", end_color="1e40af", fill_type="solid")
        ws.append(header)
        for cell in ws[1]:
            cell.font      = header_font
            cell.fill      = header_fill
            cell.alignment = Alignment(horizontal="center")

        for emp in employees:
            row_total = sum(emp["defects"].get(c, 0) for c in categories)
            ws.append([emp["name"]] + [emp["defects"].get(c, 0) for c in categories] + [row_total])

        grand_total = sum(
            sum(emp["defects"].get(c, 0) for c in categories) for emp in employees
        )
        ws.append(["GRAND TOTAL"] + [""] * len(categories) + [grand_total])
        for cell in ws[ws.max_row]:
            cell.font = Font(bold=True)

        for col_cells in ws.columns:
            values = [str(c.value) for c in col_cells if c.value is not None]
            width  = max([len(v) for v in values] + [10])
            ws.column_dimensions[col_cells[0].column_letter].width = width + 4

        buf = BytesIO()
        wb.save(buf)
        buf.seek(0)

        from flask import Response
        filename = department + "_defects_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".xlsx"
        resp = Response(
            buf.getvalue(),
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
        return resp

    except Exception as e:
        print("Export Error:", e)
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/reset", methods=["POST"])
def reset_department():
    try:
        body       = request.get_json(force=True)
        department = body.get("department")
        updated_by = body.get("updated_by") or body.get("username") or "unknown"
        if department not in DEPARTMENTS:
            return jsonify({"ok": False, "error": "Department not found"}), 404

        path          = DEPARTMENTS[department]
        existing_data = load_json(path)
        before_total  = sum(
            v for emp in existing_data.get("employees", [])
            for v in emp.get("defects", {}).values()
        )

        for emp in existing_data.get("employees", []):
            emp["defects"] = {k: 0 for k in emp.get("defects", {})}

        now = datetime.now()
        existing_data["last_updated"]    = now.isoformat()
        existing_data["last_updated_by"] = str(updated_by).strip() or "unknown"

        if not save_json(path, existing_data):
            return jsonify({"ok": False, "error": "Save failed"}), 500

        append_chart_entry(department, 0)
        append_audit_entry(department, "reset", updated_by, [{
            "type": "reset",
            "previous_total": before_total,
            "new_total": 0,
        }])

        return jsonify({"ok": True})
    except Exception as e:
        print("Reset Error:", e)
        return jsonify({"ok": False, "error": str(e)}), 500




if __name__ == "__main__":
    print()
    print("===================================")
    print("  QC CONTROL CENTER — SERVER")
    print("===================================")
    bootstrap()
    print()
    print("Open your browser at:  http://localhost:5050")
    print()
    app.run(host="0.0.0.0", port=5050, debug=True, threaded=True)
